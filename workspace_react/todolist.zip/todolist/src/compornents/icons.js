import icon_edit from '@/assets/icons/edit.png'
import icon_delete from '@/assets/icons/delete.png'

export const icon = {
  ICON_DELETE : icon_delete,
  ICON_EDIT : icon_edit
}
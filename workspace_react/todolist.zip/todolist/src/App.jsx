import { useState } from 'react'
import './App.css'
import Todolist from './compornents/Todolist'

function App() {

  return (
    <>
     <div>
      <Todolist/>
      </div>
    </>
  )
}

export default App
